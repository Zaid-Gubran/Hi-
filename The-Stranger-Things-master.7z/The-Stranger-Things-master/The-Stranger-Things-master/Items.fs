﻿namespace TheStrangerThings
    module Items =

        open GameData

        let Walkietalkie = {name = "walkie talkie";}
        let Redkey = {name = "red key";}
        let Purplekey = {name = "purple key";}
        let Mobilephone = {name = "mobile phone";}
        let Knife = {name = "knife";}
        let Baseballbat = {name = "baseball bat";}
        let Syringe = {name = "syringe";}